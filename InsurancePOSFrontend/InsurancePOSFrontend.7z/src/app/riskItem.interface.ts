export interface RiskItem {
    id: String,
    name: String
}