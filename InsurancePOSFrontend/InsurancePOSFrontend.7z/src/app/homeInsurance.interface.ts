export interface HomeInsurance {
    firstName : String;
    lastName : String;
    address : String;
    jmbg : number;
    homeSurface : String;
    homeAge : String;
    homeValue : String;
    insuranceReason : String;
    insuranceLength : number;
}