export interface TravelInsurance {
    startingDate: Date,
    endingDate: Date,
    region : string,
    numberOfPeople : number,
    ages : string,
    sport : string,
    ammount : string
}