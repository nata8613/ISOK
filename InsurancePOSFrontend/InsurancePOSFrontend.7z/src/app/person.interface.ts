export interface Person {
    firstName : String, 
    lastName : String,
    jmbg : number,
    passportNumber : number,
    address : String,
    telNum : String,
    email : String,
    index: number
}